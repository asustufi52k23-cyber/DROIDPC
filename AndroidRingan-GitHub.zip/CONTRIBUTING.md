# Kontribusi

1. Fork repository dan buat branch baru.
2. Uji perubahan skrip PowerShell di Windows 11 dan VirtualBox.
3. Jangan commit ISO Android, disk virtual, atau file VM.
4. Jelaskan perubahan dan langkah pengujian pada Pull Request.
