# Android Ringan untuk Windows 11 (RAM 4 GB)

Proyek ini menyiapkan mesin virtual Android-x86 9.0-r2 memakai Oracle VirtualBox. Tujuannya menjalankan aplikasi/game Android ringan di PC Windows 11 dengan konfigurasi hemat sumber daya.

> **Penting:** ini bukan emulator game komersial dengan kompatibilitas tinggi. Android-x86 9.0-r2 adalah rilis lama (Android 9 / Pie, 2020). Sebagian game modern, Google Play, login Google, anti-cheat, ARM-only APK, dan pemetaan kontrol game mungkin tidak bekerja. Untuk game kompetitif/berat, emulator resmi dari penerbit game biasanya lebih cocok.

## Konfigurasi awal

| Pengaturan | Nilai |
|---|---:|
| RAM VM | 1024 MB (bisa dinaikkan ke 1536 MB jika Windows masih lancar) |
| CPU virtual | 2 |
| Video memory | 64 MB |
| Disk virtual | 16 GB, dinamis |
| Jaringan | NAT |
| Resolusi awal | Atur dari Android setelah instalasi; mulai 1280x720 bila didukung |

VirtualBox mengambil RAM dari Windows saat VM berjalan. Pada PC RAM 4 GB, tutup browser dan aplikasi lain sebelum menjalankan Android. Bila Windows menjadi lambat, matikan VM atau turunkan pemakaian aplikasi latar belakang.

## Persyaratan

1. Windows 11 64-bit.
2. Virtualisasi perangkat keras (Intel VT-x / AMD-V) aktif di BIOS/UEFI.
3. Oracle VirtualBox terpasang. Unduh dari situs resmi: https://www.virtualbox.org/wiki/Downloads
4. Ruang kosong minimal sekitar 20 GB.
5. Koneksi internet untuk mengunduh ISO Android-x86 (sekitar 966 MB).

## Instalasi

1. Pasang VirtualBox dari situs resminya, lalu restart Windows jika diminta.
2. Ekstrak ZIP proyek ini ke folder biasa, misalnya `C:\AndroidRingan`.
3. Klik kanan `scripts\download-android-x86.ps1` → **Run with PowerShell**, atau buka PowerShell di folder proyek dan jalankan:

   ```powershell
   Set-ExecutionPolicy -Scope Process Bypass
   .\scripts\download-android-x86.ps1
   ```

   Skrip mengunduh ISO resmi dari SourceForge dan memeriksa SHA-256. File ISO tidak disertakan di ZIP karena ukurannya hampir 1 GB.

4. Buat VM dan boot installer:

   ```powershell
   .\scripts\create-vm.ps1
   ```

5. Pada menu boot Android-x86, pilih **Installation - Install Android-x86 to harddisk**.
6. Di utilitas partisi:
   - Pilih `Create/Modify partitions`.
   - Jika diminta GPT, pilih `No` untuk tabel MBR sederhana.
   - Buat partisi baru `Primary`, gunakan seluruh disk, lalu pilih `Bootable`.
   - Pilih `Write`, ketik `yes`, lalu `Quit`.
   - Pilih partisi yang baru dibuat (umumnya `sda1`), format sebagai `ext4`, konfirmasi.
   - Setujui pemasangan GRUB. Jika ditanya membuat `/system` read-write, pilih **Yes**.
7. Setelah instalasi selesai, pilih **Reboot**. Jika VM kembali masuk installer, matikan VM lalu jalankan:

   ```powershell
   .\scripts\detach-iso.ps1
   ```

   Kemudian jalankan `.\scripts\start-vm.ps1`.

8. Ikuti pengaturan awal Android. Untuk memasang APK milik sendiri, gunakan menu **Devices → Insert Guest Additions CD Image** hanya jika diperlukan (dukungan Android-x86 terbatas), atau gunakan ADB dari Android SDK Platform Tools jika sudah dikonfigurasi.

## Menjalankan dan mengelola

- Jalankan: `.\scripts\start-vm.ps1`
- Buka VirtualBox Manager dan pilih `AndroidRingan` untuk mengubah RAM/CPU.
- Matikan Android melalui menu daya di dalam Android. Hindari menutup paksa VM saat sedang menulis data.
- Hapus VM: gunakan VirtualBox Manager. Pilih **Remove** lalu **Delete all files** hanya jika ingin menghapus seluruh data Android.

## Pengaturan RAM

Default 1024 MB dipilih agar Windows 11 masih memiliki ruang pada komputer RAM 4 GB. Android mungkin lebih lambat pada 1 GB. Jika host tetap responsif, ubah RAM VM menjadi 1536 MB melalui VirtualBox Manager → Settings → System → Motherboard. Jangan mengalokasikan 2 GB pada host RAM 4 GB kecuali memahami risiko Windows kehabisan RAM.

## Troubleshooting

- **VT-x/AMD-V unavailable:** aktifkan Intel Virtualization Technology / SVM Mode di BIOS/UEFI. Jika Hyper-V/Windows Hypervisor Platform bentrok pada sistem tertentu, periksa pengaturan Windows dan dokumentasi VirtualBox.
- **ISO tidak ditemukan:** jalankan ulang `download-android-x86.ps1`.
- **VM tidak bisa dibuat:** pastikan VirtualBox terpasang dan `VBoxManage.exe` tersedia.
- **Layar hitam/grafis bermasalah:** matikan VM, buka Settings → Display, coba Graphics Controller `VBoxSVGA` atau `VBoxVGA`; pertahankan Video Memory 64 MB dan nonaktifkan 3D Acceleration.
- **Game tidak kompatibel:** Android-x86 9 adalah Android 9 dan arsitektur x86_64; game modern/ARM-only/anti-cheat dapat gagal. Proyek ini tidak menjamin kompatibilitas semua game.

## Struktur proyek

```text
AndroidRingan-Windows11/
├── README.md
├── LICENSE
├── .gitignore
├── iso/
│   └── (ISO diunduh lokal, tidak masuk Git)
└── scripts/
    ├── download-android-x86.ps1
    ├── create-vm.ps1
    ├── start-vm.ps1
    └── detach-iso.ps1
```

## Sumber dan lisensi

- Android-x86: https://www.android-x86.org/
- Catatan rilis Android-x86 9.0-r2: https://www.android-x86.org/releases/releasenote-9-0-r2.html
- Unduhan Android-x86: https://sourceforge.net/projects/android-x86/files/
- Oracle VirtualBox: https://www.virtualbox.org/

Android-x86 merupakan proyek terpisah dan lisensinya mengikuti komponen masing-masing (AOSP/Apache, GPL, dan lainnya). Oracle VirtualBox didistribusikan dengan lisensi Oracle. Proyek skrip ini tidak menyertakan atau mengubah kedua perangkat lunak tersebut.


## Repository GitHub

ZIP ini berisi **isi repository**, bukan file ISO atau mesin virtual siap pakai. Ekstrak ZIP, lalu unggah semua isi folder (termasuk folder `.github`) ke repository GitHub. Workflow GitHub Actions akan memeriksa sintaks skrip PowerShell pada setiap push dan pull request.

Untuk menghindari repository terlalu besar, ISO Android-x86 diunduh secara terpisah ke folder `iso/` dan tidak dilacak Git.
