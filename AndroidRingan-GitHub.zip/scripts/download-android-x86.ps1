$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$IsoDir = Join-Path $ProjectRoot "iso"
$IsoPath = Join-Path $IsoDir "android-x86_64-9.0-r2.iso"
$Url = "https://sourceforge.net/projects/android-x86/files/Release%209.0/android-x86_64-9.0-r2.iso/download"

New-Item -ItemType Directory -Force -Path $IsoDir | Out-Null

if (Test-Path $IsoPath) {
    Write-Host "ISO sudah ada: $IsoPath"
    $answer = Read-Host "Unduh ulang? (y/N)"
    if ($answer -notmatch '^(y|yes)$') { exit 0 }
    Remove-Item $IsoPath -Force
}

Write-Host "Mengunduh Android-x86 9.0-r2 (file besar, sekitar 1 GB)."
Invoke-WebRequest -Uri $Url -OutFile $IsoPath
if (-not (Test-Path $IsoPath) -or (Get-Item $IsoPath).Length -lt 100MB) {
    if (Test-Path $IsoPath) { Remove-Item $IsoPath -Force }
    throw "Unduhan tampak tidak lengkap. Coba lagi dari halaman resmi Android-x86."
}

Write-Host "Unduhan selesai: $IsoPath" -ForegroundColor Green
Write-Host "Catatan: periksa checksum yang dipublikasikan oleh proyek sumber sebelum instalasi jika tersedia."
