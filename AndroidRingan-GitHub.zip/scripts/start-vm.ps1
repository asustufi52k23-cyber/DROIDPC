$ErrorActionPreference = "Stop"
$vboxCmd = Get-Command "VBoxManage.exe" -ErrorAction SilentlyContinue
if ($vboxCmd) {
    $vbox = $vboxCmd.Source
} else {
    $vbox = Join-Path $env:ProgramFiles "Oracle\VirtualBox\VBoxManage.exe"
}
if (-not (Test-Path $vbox)) { throw "VirtualBox tidak ditemukan. Pasang Oracle VirtualBox terlebih dahulu." }
& $vbox startvm "AndroidRingan"
if ($LASTEXITCODE -ne 0) { throw "Gagal menjalankan VM. Pastikan VM sudah dibuat." }
