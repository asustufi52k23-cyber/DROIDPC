$ErrorActionPreference = "Stop"
$vboxCmd = Get-Command "VBoxManage.exe" -ErrorAction SilentlyContinue
if ($vboxCmd) {
    $vbox = $vboxCmd.Source
} else {
    $vbox = Join-Path $env:ProgramFiles "Oracle\VirtualBox\VBoxManage.exe"
}
if (-not (Test-Path $vbox)) { throw "VirtualBox tidak ditemukan." }

$state = & $vbox showvminfo "AndroidRingan" --machinereadable
if ($LASTEXITCODE -ne 0) { throw "VM AndroidRingan tidak ditemukan." }
if ($state -match 'VMState="running"') {
    throw "Matikan VM terlebih dahulu melalui Android/VirtualBox, lalu jalankan skrip ini."
}
& $vbox storageattach "AndroidRingan" --storagectl "IDE" --port 0 --device 0 --type dvddrive --medium emptydrive
if ($LASTEXITCODE -ne 0) { throw "Gagal melepas ISO." }
Write-Host "ISO installer dilepas. Jalankan scripts\start-vm.ps1 untuk boot dari disk." -ForegroundColor Green
