$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$IsoPath = Join-Path $ProjectRoot "iso\android-x86_64-9.0-r2.iso"
$VmName = "AndroidRingan"

function Find-VBoxManage {
    $cmd = Get-Command "VBoxManage.exe" -ErrorAction SilentlyContinue
    if ($cmd) { return $cmd.Source }
    $candidate = Join-Path $env:ProgramFiles "Oracle\VirtualBox\VBoxManage.exe"
    if (Test-Path $candidate) { return $candidate }
    throw "VBoxManage.exe tidak ditemukan. Pasang Oracle VirtualBox terlebih dahulu."
}

if (-not (Test-Path $IsoPath)) {
    throw "ISO belum ada. Jalankan scripts\download-android-x86.ps1 terlebih dahulu."
}
$vbox = Find-VBoxManage
$existing = & $vbox list vms
if ($existing -match ('"' + [regex]::Escape($VmName) + '"')) {
    throw "VM '$VmName' sudah terdaftar. Buka VirtualBox Manager atau hapus VM lama sebelum membuat ulang."
}

$vmDir = Join-Path $ProjectRoot "virtual-machines"
New-Item -ItemType Directory -Force -Path $vmDir | Out-Null
$diskPath = Join-Path $vmDir "AndroidRingan.vdi"

& $vbox createvm --name $VmName --ostype "Linux_64" --basefolder $vmDir --register
if ($LASTEXITCODE -ne 0) { throw "Gagal membuat VM." }

& $vbox modifyvm $VmName --memory 1024 --cpus 2 --vram 64 --graphicscontroller vmsvga --nic1 nat --boot1 dvd --boot2 disk --boot3 none --boot4 none
if ($LASTEXITCODE -ne 0) { throw "Gagal mengatur VM." }

& $vbox createmedium disk --filename $diskPath --size 16384 --format VDI --variant Standard
if ($LASTEXITCODE -ne 0) { throw "Gagal membuat disk virtual." }

& $vbox storagectl $VmName --name "SATA" --add sata --controller IntelAhci
& $vbox storageattach $VmName --storagectl "SATA" --port 0 --device 0 --type hdd --medium $diskPath
& $vbox storagectl $VmName --name "IDE" --add ide
& $vbox storageattach $VmName --storagectl "IDE" --port 0 --device 0 --type dvddrive --medium $IsoPath
if ($LASTEXITCODE -ne 0) { throw "Gagal memasang ISO." }

Write-Host ""
Write-Host "VM AndroidRingan berhasil dibuat." -ForegroundColor Green
Write-Host "Installer Android-x86 akan dibuka sekarang."
& $vbox startvm $VmName
if ($LASTEXITCODE -ne 0) { throw "VM dibuat, tetapi gagal dijalankan. Coba buka dari VirtualBox Manager." }
