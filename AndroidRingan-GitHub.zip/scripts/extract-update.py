#!/usr/bin/env python3
"""Safely extract a user-uploaded revision ZIP into the repository root."""
from __future__ import annotations

import sys
import zipfile
from pathlib import Path, PurePosixPath

MAX_FILES = 10_000
MAX_TOTAL_UNCOMPRESSED = 500 * 1024 * 1024  # 500 MiB
REPO_ROOT = Path(__file__).resolve().parents[1]


def safe_target(member_name: str) -> Path:
    # ZIP paths conventionally use forward slashes, even on Windows.
    raw = member_name.replace("\\", "/")
    path = PurePosixPath(raw)

    if not raw or path.is_absolute() or any(part in ("", ".", "..") for part in path.parts):
        raise ValueError(f"Unsafe path in ZIP: {member_name!r}")
    if path.parts and (":" in path.parts[0] or path.parts[0].lower() == ".git"):
        raise ValueError(f"Disallowed path in ZIP: {member_name!r}")
    if any(part.lower() == ".git" for part in path.parts):
        raise ValueError(f"Disallowed .git path in ZIP: {member_name!r}")
    if any(part == "__MACOSX" for part in path.parts):
        raise ValueError(f"Unnecessary metadata path in ZIP: {member_name!r}")

    target = (REPO_ROOT / Path(*path.parts)).resolve()
    if target != REPO_ROOT and REPO_ROOT not in target.parents:
        raise ValueError(f"Path escapes repository: {member_name!r}")
    return target


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python scripts/extract-update.py updates/revision.zip", file=sys.stderr)
        return 2

    archive = Path(sys.argv[1]).resolve()
    if not archive.is_file() or archive.suffix.lower() != ".zip":
        print(f"ZIP file not found: {archive}", file=sys.stderr)
        return 2

    try:
        with zipfile.ZipFile(archive) as zf:
            members = [m for m in zf.infolist() if not m.is_dir()]
            if len(members) > MAX_FILES:
                raise ValueError(f"ZIP contains too many files ({len(members)}). Limit: {MAX_FILES}.")

            total_size = sum(m.file_size for m in members)
            if total_size > MAX_TOTAL_UNCOMPRESSED:
                raise ValueError("ZIP expands beyond the 500 MiB safety limit.")

            # Validate every entry before writing any files.
            planned = []
            for member in members:
                target = safe_target(member.filename)
                # Reject Unix symbolic links; only regular files are expected in code revisions.
                unix_mode = (member.external_attr >> 16) & 0xFFFF
                if (unix_mode & 0o170000) == 0o120000:
                    raise ValueError(f"Symbolic links are not allowed: {member.filename!r}")
                planned.append((member, target))

            for member, target in planned:
                target.parent.mkdir(parents=True, exist_ok=True)
                with zf.open(member, "r") as source, target.open("wb") as destination:
                    while chunk := source.read(1024 * 1024):
                        destination.write(chunk)
                print(f"Extracted: {target.relative_to(REPO_ROOT)}")

    except (zipfile.BadZipFile, OSError, ValueError) as exc:
        print(f"ZIP import failed: {exc}", file=sys.stderr)
        return 1

    print(f"Successfully imported {len(members)} file(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
