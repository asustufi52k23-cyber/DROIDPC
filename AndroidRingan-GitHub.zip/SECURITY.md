# Pelaporan Keamanan

Jangan mengirim file ISO, APK, atau disk virtual yang tidak dipercaya. Untuk laporan kerentanan pada skrip proyek ini, buka GitHub Security Advisory pada repository tempat proyek ini diunggah. Jangan publikasikan informasi sensitif sebelum ada perbaikan.
