# Upload ZIP revisions here

Untuk memperbarui kode melalui ZIP:

1. Buat ZIP revisi dengan struktur file dimulai dari root repository (contoh: `README.md`, `scripts/start-vm.ps1`), bukan folder pembungkus tambahan.
2. Upload ZIP ke folder `updates/` di GitHub.
3. Commit upload tersebut ke branch default repository.
4. GitHub Actions akan mengekstrak file, menghapus ZIP yang diunggah, lalu membuat commit otomatis.

Jangan upload ZIP dari sumber yang tidak dipercaya. Workflow akan menolak path traversal, symbolic link, arsip lebih dari 500 MiB setelah diekstrak, dan file berjumlah lebih dari 10.000.
